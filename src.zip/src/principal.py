from vcde import VCDE



vcde=VCDE(2021,10,2021,12)
vcde.obtencion_registros_diarios()
