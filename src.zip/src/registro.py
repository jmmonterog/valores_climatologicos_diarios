

class Registro:

    def __init__(self,fecha,valores):
        self.fecha = fecha
        self.valores = valores


